

# Optimization Notes
## Modeling, Algorithms, and Complexity with Examples in Python and Julia

These notes were originally written by Dr. Douglas Bish for a course on linear programing at Virginia Tech.

These notes are licenced under the creative commons licnese CC BY SA 4.0.
See [http://creativecommons.org/licenses/by-sa/4.0/] for details on this liense.


These notes have been modified by Robert Hildebrand.

The modification maintains the CC BY SA License.
