
# Acknowledgements

We greatly thank all contributors to this project.  This project could not exist without your help and ongoing support.  The contributors listed below will be acknowledged for their effort in any resulting manuscripts under open optimization.  If you wish to have your name removed from below, or of you have not been acknowledged for your contributions, please contact [open-optimization@vt.edu](mailto:open-optimization@vt.edu).



Douglas Bish, Virginia Tech
Robert Hildebrand, Virginia Tech
Matthias Koeppe, University of California, Davis
Laurent Porrier, University of Waterloo
Tamon Stephen, Simon Fraser University
