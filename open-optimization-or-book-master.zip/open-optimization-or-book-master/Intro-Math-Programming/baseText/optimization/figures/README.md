# Proper citations!!
Please see the Metadata file in each folder to find who to give proper credit for these images.

Everything here is CC-BY-SA 4.0 (or more open).  
