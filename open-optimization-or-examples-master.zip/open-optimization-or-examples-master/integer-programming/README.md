# Integer Programming Examples
Each folder has a type of problem with an example(s) of instance and code to solve these problems.

