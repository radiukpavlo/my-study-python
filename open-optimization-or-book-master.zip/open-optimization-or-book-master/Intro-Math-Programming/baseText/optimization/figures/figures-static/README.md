## static figures (not generated)

These figures have been obtained from various sources.

To keep track of their metadata, sources, and licensing, see [00_METADATA.bib](00_METADATA.bib)
