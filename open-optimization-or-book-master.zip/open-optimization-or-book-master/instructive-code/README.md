This directory contains code that is meant for the use of the instructors using the book,
and for course developers for generating illustrations etc.  It is not primarily intended for use by students studying the book.
