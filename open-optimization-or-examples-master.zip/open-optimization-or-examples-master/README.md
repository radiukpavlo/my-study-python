# open-optimization-or-examples
Examples of operations research models with code attached

Please see these sites for lots of great examples:
- https://github.com/MOSEK/Tutorials
- https://github.com/Gurobi/modeling-examples
- https://jckantor.github.io/ND-Pyomo-Cookbook/
- https://github.com/jump-dev/JuMP.jl/tree/master/docs/src/tutorials
