This directory contains LaTeX versions of the markdown files.
Do not edit.  We keep these generated files in the repository so that
projects that include them can be compiled with LaTeX only, avoiding
a dependency on pandoc.
